<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "documents";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Fetch data from birthcertificate table
$sql = "SELECT * FROM residentcertificate";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // Output data of each row
  while($row = $result->fetch_assoc()) {
    echo "<tr>";
    echo "<td>" . $row["id"] . "</td>";
    echo "<td>" . $row["name"] ."</td>";
    echo "<td>" . $row["status"] . "</td>";
    echo "<td><a href='viewres.php?id=" . $row["id"] . "'>View Details</a></td>";
    echo "</tr>";
  }
} else {
  echo "0 results";
}
$conn->close();
?>
